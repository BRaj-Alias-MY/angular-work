import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Question } from '../../question';
declare var $: any;
declare const CameraTag: any;

@Component({
  selector: 'app-interview',
  templateUrl: './interview.component.html',
  styleUrls: ['./interview.component.css']
})
export class InterviewComponent implements OnInit {

  myCamera: any;
  status: any;
  questions = {};
  videoURL: any;
  POST_URL = "http://localhost:8000/api/update2";
  data = {};
  question: Question;

  id = 2;
  uid = 'testtt';
  answer = 'ans';
  userId = 1;
  status2 = 1;
  title = 'mycam1';

  constructor(private service: AppService, private http: HttpClient, private router: Router) {
    this.question = new Question();
  }

  ngOnInit() {

    $(document).ready(function () {
      CameraTag.setup();
      CameraTag.observe("myCamera", "initialized", function () {
        // $('.cameratag_record').trigger('click');
        //$('#myCamera').addClass('pointers');

      });


      CameraTag.observe("myCamera", "readyToPublish", function () {
        let status = CameraTag.cameras["myCamera"].getState();
        if (status == 'readyToPublish') {
          CameraTag.cameras["myCamera"].publish();

          // this.service.postQuestion(1, 'test', 'testing', 1, 1).subscribe(resp => console.log(resp), err => console.log(err));

        }

      });

      CameraTag.observe("myCamera", "published", function () {
        let video = CameraTag.cameras["myCamera"].getVideo();
        localStorage.setItem('videoid', video.uuid);
        console.log(video.uuid);
        //  $('.cameratag_record').trigger('click');
        //  $('#myCamera').click(function () { return false; });


        //  this.service.postQuestion(1, 'test', 'testing', 1, 1).subscribe(resp => console.log(resp), err => console.log(err));


      });


      CameraTag.observe("myCamera", "uploadProgress", function () {
        let state = CameraTag.cameras["myCamera"].getState();

        // console.log(state);

        //  this.service.postQuestion(1, 'test', 'testing', 1, 1).subscribe(resp => console.log(resp), err => console.log(err));


      });

    });

    //getting questions
    this.getQuestions();


  }

  getQuestions() {
    this.service.getQuestion().subscribe(resp => { console.log(resp); this.questions = resp; }, err => console.log(err));
  }

  commit() {
    CameraTag.cameras["myCamera"].stopRecording();
    this.status = CameraTag.cameras["myCamera"].getState();
    //CameraTag.cameras["myCamera"].publish()
    //this.service.postQuestion('test', 'testing', 1, 1, 1).subscribe(resp => console.log(resp), err => console.log(err));


    //console.log(this.question.answer);

    /*
    if (this.status == 'readyToPublish') {
      $('#cameratag_publish').publish();
      console.log('hello test');
    }
  */

  }



  reset(id, max) {
    //alert(id);
    CameraTag.cameras["myCamera"].reset();
    this.question.id = id;
    this.question.uid = localStorage.getItem('videoid');
    this.question.answer = 'hello new test ';
    this.question.userId = 1;
    this.question.status = 1;
    this.question.time_taken = $('.cameratag_record_timer_prompt').html();
    let maxcount = max;
    alert(id + '/' + maxcount)
    if (id <= 4) {

      this.http.post(this.POST_URL, this.question)
        .subscribe(resp => { console.log(resp); localStorage.setItem('videoid', ''); }, err => console.log(err), () => { this.getQuestions(); $('.cameratag_record').trigger('click'); if (id == maxcount) { CameraTag.cameras["myCamera"].destroy(); this.router.navigate(['/finish']) } });
      $('.cameratag_record').trigger('click');


    }

  }

}
