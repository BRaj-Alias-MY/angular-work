import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {
  MatButtonModule, MatListModule, MatGridListModule, MatCardModule,
  MatInputModule, MatCheckboxModule, MatIconModule, MatSidenavModule,
  MatMenuModule, MatToolbarModule, MatExpansionModule, MatTabsModule, MatChipsModule
} from '@angular/material';
import { MainComponent } from './layout/main/main.component';

import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './layout/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { Dashboard2Component } from './pages/dashboard2/dashboard2.component';
import { TopComponent } from './layout/top/top.component';
import { InterviewComponent } from './pages/interview/interview.component';
import { InterviewSessionComponent } from './pages/interview-session/interview-session.component';
import { HttpClientModule } from '@angular/common/http';
import { ExamComponent } from './layout/exam/exam.component';
import { EntrypageComponent } from './layout/exam/entrypage/entrypage.component';
import { InstructionsComponent } from './layout/exam/instructions/instructions.component';
import { MockComponent } from './layout/exam/mock/mock.component';
import { FinishComponent } from './layout/exam/finish/finish.component';
import { DisplayExamsComponent } from './layout/exam/display-exams/display-exams.component';



const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  {
    path: 'main', component: MainComponent, children: [
      { path: 'main', component: MainComponent, outlet: 'main' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'dashboard2', component: Dashboard2Component }


    ]
  },
  { path: 'interview', component: InterviewComponent },
  {
    path: 'examboard', component: ExamComponent, children: [
      { path: 'examboard', component: ExamComponent, outlet: 'exam' },
      { path: 'entrypage', component: EntrypageComponent },
      { path: 'instructions', component: InstructionsComponent },
      { path: 'mock', component: MockComponent },
      { path: 'finish', component: FinishComponent },
      { path: 'interviews', component: DisplayExamsComponent }
    ]
  },

];

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    LoginComponent,
    DashboardComponent,
    Dashboard2Component,
    TopComponent,
    InterviewComponent,
    InterviewSessionComponent,
    ExamComponent,
    EntrypageComponent,
    InstructionsComponent,
    MockComponent,
    FinishComponent,
    DisplayExamsComponent
  ],
  imports: [
    BrowserModule, MatChipsModule, HttpClientModule, BrowserAnimationsModule, MatIconModule, MatGridListModule, MatMenuModule,
    MatCardModule, BrowserAnimationsModule, MatSidenavModule, MatExpansionModule,
    MatButtonModule, MatListModule, MatCheckboxModule, MatInputModule, MatToolbarModule, MatTabsModule, RouterModule.forRoot(routes)
  ],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
