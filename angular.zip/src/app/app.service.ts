import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class AppService {
  URL = "http://localhost:8000/api/myexam";
  POST_URL = "http://localhost:8000/api/update2";
  constructor(private http: HttpClient) { }

  getQuestion() {
    return this.http.get<any>(this.URL);
  }
  postQuestion(uid: string, answer: string, userId: number, status: number, id: number) {

    return this.http.post(this.POST_URL, JSON.stringify({ uid: uid, answer: answer, userId: userId, status: status, id: id }))

  }
}
