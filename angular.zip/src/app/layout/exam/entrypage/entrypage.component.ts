import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entrypage',
  templateUrl: './entrypage.component.html',
  styleUrls: ['./entrypage.component.css']
})
export class EntrypageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
