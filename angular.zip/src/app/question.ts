export class Question {

    id: number;
    uid: string;
    answer: string;
    userId: number;
    status: number;
    time_taken: string;
}